# Program name: Vega_London_M15_Final_Project
# Author: London Vega
# Date: 11/19/2021
# Summary: This program contains a basic calculator
# Variables:
#

import tkinter

# Setting up the window for the calculator

class BasicCalculatorGUI:
    def __init__(self):
        self.MainWindow = tkinter.Tk()
        self.MainWindow.title("Basic Calculator")

        # Setting up frames for the calculator
        

        
 
